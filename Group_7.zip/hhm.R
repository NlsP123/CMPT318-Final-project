
# ============================================================
# Installations
# ============================================================

# Install ggbiplot
install.packages("remotes")
remotes::install_github("vqv/ggbiplot")

# Install depmixS4
install.packages("depmixS4")



# ============================================================
# Question 1
# ============================================================

# Load libraries
library(ggbiplot)

# ------------------------------------------------------------
# Functions
# ------------------------------------------------------------

# Function for reading the dataset and parsing the time.
read_dataset <- function(f) {
  raw <- read.csv(f)
  raw$Time <- strptime(
    paste(raw$Date, " ", raw$Time),
    format =  "%d/%m/%Y %H:%M:%S"
  )

  # Extract the day of week and week of year.
  raw$Weekday <- raw$Time$wday
  raw$Week    <- as.integer(strftime(raw$Time, format = "%U"))

  # Remove the extraneous $Date field, since $Time covers that.
  raw <- subset(raw, select = -Date)
  return(raw)
}

# Function for interpolating NA values.
interpolate_na <- function(data) {
  # Fill leading and trailing values.
  # Approx won't be able to interpolate them.

  i_first_non_na <- which(!is.na(data))[1]
  if (i_first_non_na > 1) {
    i_leading_na <- c(1:i_first_non_na - 1)
    data[i_leading_na] <- data[i_first_non_na]
  }

  i_last_non_na  <- length(data) - which(!is.na(rev(data)))[1] + 1
  if (i_last_non_na < length(data)) {
    i_trailing_na <- c(last_first_non_na + 1:length(data))
    data[i_trailing_na] <- data[i_last_non_na]
  }

  # Find out which rows are NA.
  i_na <- c(which(is.na(data)))
  if (length(i_na) == 0) {
    return(data)
  }
  
  # Interpolate and get the value of those NA rows.
  na_approxed <- approx(
    c(1:length(data)),
    data,
    xout = i_na
  )$y

  # Copy back interpolated values.
  data[i_na] <- unlist(na_approxed)
  return(data)
}


# ------------------------------------------------------------
# Read and Clean the Dataset
# ------------------------------------------------------------

dataset <- read_dataset("~/Downloads/TermProjectData.txt")
dataset$Global_active_power   = interpolate_na(dataset$Global_active_power)
dataset$Global_reactive_power = interpolate_na(dataset$Global_reactive_power)
dataset$Voltage               = interpolate_na(dataset$Voltage)
dataset$Global_intensity      = interpolate_na(dataset$Global_intensity)
dataset$Sub_metering_1        = interpolate_na(dataset$Sub_metering_1)
dataset$Sub_metering_2        = interpolate_na(dataset$Sub_metering_2)
dataset$Sub_metering_3        = interpolate_na(dataset$Sub_metering_3)

# ------------------------------------------------------------
# Partition the Dataset
# ------------------------------------------------------------

is_training_data <- function(ds) {
  (ds$Week %% 4 == 0)
}

training_dataset <- dataset[is_training_data(dataset),]
testing_dataset <- dataset[!is_training_data(dataset),]

# ------------------------------------------------------------
# Prepare Dataset for PCA
# ------------------------------------------------------------

# Using the full sized training data makes the plotted PCA illegible.
# Instead, we're going to take one sample every 15 hours and 13 minutes.
#   This gives us a wide range of coverage at all hours of the day while
#   reducing the number of observations down to a more-manageable 472.

resample_interval_seconds <- (60 * 60 * 15) + (60 * 13)
feature_cols <- c(
  "Global_active_power", 
  "Global_reactive_power",
  "Voltage",
  "Global_intensity",
  "Sub_metering_1",
  "Sub_metering_2",
  "Sub_metering_3"
)

training_dataset <- training_dataset
training_dataset$AggregateID <- as.integer(
  as.numeric(training_dataset$Time) / resample_interval_seconds
)

# Create a function that can be used with aggregate.
# This function will take the first value and ignore the rest.
first <- function(x) {
  x[1]
}

# Re-sample the training dataset.
pca_dataset <- data.frame(
  Time = as.POSIXlt(
           aggregate(
             as.numeric(Time) ~ AggregateID,
             training_dataset, first
           )[,2]
         ),
  Weekday = aggregate(
             Weekday ~ AggregateID,
             training_dataset, first
           )[,2],
  Week = aggregate(
             Week ~ AggregateID,
             training_dataset, first
           )[,2]
)

for (v in feature_cols) {
  pca_dataset[[v]] <- scale(aggregate(
    as.formula(paste(v, "~ AggregateID")), 
    training_dataset,
    FUN = first
  ))[,2]
}

# ------------------------------------------------------------
# Perform PCA
# ------------------------------------------------------------

# Perform the PCA on the re-sampled dataset.
training_pca <- prcomp(subset(pca_dataset, select = feature_cols))

# ------------------------------------------------------------
# Analyse PCA
# ------------------------------------------------------------

# Render the scree plot.
ggscreeplot(training_pca)

# Show the variance coverage.
summary(training_pca)

# Plot PC1 and PC2
ggbiplot(training_pca,
  ellipse = TRUE,
  circle = TRUE,
  choices = 1:2,
  alpha = 0.5,
  obs.scale = 1,
  var.scale = 1
)

# Plot PC3 and PC4
ggbiplot(training_pca,
  ellipse = TRUE,
  circle = TRUE,
  choices = 3:4,
  alpha = 0.5,
  obs.scale = 1,
  var.scale = 1
)

# Get the loadings for each of the first four components.
loadings <- princomp(cor(subset(pca_dataset, select = feature_cols)))$loadings[,1:4]

# Multiply the loadings by how much variance the component captures.
loadings[,1] = loadings[,1] * 0.3845
loadings[,2] = loadings[,2] * 0.1513
loadings[,3] = loadings[,3] * 0.1431
loadings[,4] = loadings[,4] * 0.1207

# Sum up the columns and sort:
sort(rowSums(abs(loadings)))


# ============================================================
# Question 2
# Following from the previous question:
# ============================================================

# Load libraries
library(depmixS4)

# ------------------------------------------------------------
# Functions
# ------------------------------------------------------------

# Function for extracting a window from 10 AM to 3 PM.
weekday <- 6                  # Saturday
timewindow_start  <- 60 * 10  # Hour 10
timewindow_length <- 60 * 5

extract_window <- function(data) {
  win <- subset(data, Weekday == weekday & (
    (Time$hour*60)+Time$min >= timewindow_start &
    (Time$hour*60)+Time$min <= (timewindow_start + timewindow_length)
  ))
  
  win$MinOfDay <- win$Time$hour * 60
  win$MinOfDay <- win$MinOfDay + win$Time$min
  return(win)
}

# Function for counting the ntimes for a given window.
ntimes_of_window <- function(window) {
  days <- unique(window$Time$yday)
  nrow_by_days <- table(window$Time$yday)
  sapply(days, function(day) {
    as.integer(nrow_by_days[as.character(day)])
  })
}


# Function for training HMMs.
formula <- MinOfDay ~ Global_intensity + Global_active_power + Sub_metering_3

hmms_train <- function(training_data, states_min, stats_max, states_by) {
  model_objs  <- list()
  model_stats <- data.frame(
      nstates = seq(states_min, stats_max, by = states_by),
      loglik = 0,
      bic = 0
  )

  ntimes <- ntimes_of_window(training_data)
  for (ns in model_stats$nstates) {
    row <- match(ns, model_stats$nstates)

    print(paste(ns, "states:"))
    set.seed(0)
    model <- depmix(
      response = formula,
      data     = training_data,
      nstates  = ns,
      ntimes   = ntimes,
    )
    fit_model <- fit(model)

    model_objs[row] <- fit_model
    model_stats$loglik[row] <- logLik(fit_model)
    model_stats$bic[row] <- BIC(fit_model)
    print(paste(ns, "BIC =", BIC(fit_model)))
  }

  return(list(
    models = model_objs,
    stats = model_stats
  ))
}

# Function for plotting HMMs created with training data.
hmms_plot <- function(stats) {
  logliks <- scale(stats$loglik)
  bics <- scale(stats$bic) * -1
  
  y_min <- min(min(logliks), min(bics))
  y_max <- max(max(logliks), max(bics))

  # Create a plot.
  plot.new()
  plot.window(
      xlim = c(min(stats$nstates), max(stats$nstates)),
      ylim = c(y_min, y_max)
  )
  title(
      main = "HMM logLik v. BIC",
      xlab = "States", ylab = "Value"
  )

  x_label_at <- stats$nstates
  axis(side = 1, at = x_label_at)
  axis(side = 2, at = seq(-3, 3, by = 0.5), las = 2)

  legend(
      "topleft",
      legend=c("Log-Likelihood", "BIC x -1"),
      col=c("red", "blue"),
      pch=1
  )

  # Create vertical bars to make it easier to see where data lies.
  for (ns in stats$nstates) {
      segments(x0=ns, y0=-3, x1=ns, y1=3, col="grey")
  }

  # Add lines to the plot.
  lines(stats$nstates, logliks, col="red")
  lines(stats$nstates, bics, col="blue")
}




# ------------------------------------------------------------
# Data Preparation
# ------------------------------------------------------------

# Scale the training and test datasets
scaled_training_dataset <- training_dataset
scaled_testing_dataset <- testing_dataset
for (v in feature_cols) {
  scaled_training_dataset[[v]] <- scale(training_dataset[[v]])[,1]
  scaled_testing_dataset[[v]] <- scale(testing_dataset[[v]])[,1]
}


# ------------------------------------------------------------
# HMM Training
# ------------------------------------------------------------

hmm_training_dataset <- extract_window(scaled_training_dataset)

# Fit and plot HMMs: 4 to 24, interval 4
hmms <- hmms_train(hmm_training_dataset, 4, 24, 4)
hmms_plot(hmms$stats)

# Fit and plot HMMs: 16 to 24, interval 4
hmms2 <- hmms_train(hmm_training_dataset, 16, 24, 2)
hmms_plot(hmms2$stats)

# Fit and plot HMMs: 18 to 22, interval 1
hmms3 <- hmms_train(hmm_training_dataset, 18, 22, 1)
hmms_plot(hmms3$stats)

# Create a 20-state model using training data
set.seed(0)
hmm_ntimes <- ntimes_of_window(hmm_training_dataset)
model <- depmix(
  response = formula,
  data     = hmm_training_dataset,
  nstates  = 20,
  ntimes   = hmm_ntimes
)

fit_model <- fit(model)

# ------------------------------------------------------------
# HMM Testing
# ------------------------------------------------------------

# Use the model parameters with the testing partition.
test_data <- extract_window(scaled_testing_dataset)
test_ntimes <- ntimes_of_window(test_data)
test_hmm <- depmix(
  response = formula,
  data     = test_data,
  nstates  = 20,
  ntimes   = test_ntimes
)

test_hmm <- setpars(test_hmm, getpars(fit_model))


# Get the standarized log-likelihood for the training partition.
train_result <- forwardbackward(fit_model)$logLik / sum(hmm_ntimes)
print(train_result)

# Get the standarized log-likelihood for the testing partition.
test_result <- forwardbackward(test_hmm)$logLik / sum(test_ntimes)
print(test_result)

# Compare the log-likelihoods.
abs(train_result - test_result)  # 0.06420277




# ============================================================
# Question 3
# Following from the previous question:
# ============================================================

# Load libraries
library(depmixS4)

# ------------------------------------------------------------
# Functions
# ------------------------------------------------------------

eval_loglik <- function(win) {
  win$Week <- floor(win$Time$yday / 7) + 1
  weeks <- unique(sort(win$Week))
  lls <- data.frame(
    Week = weeks,
    LL = c(NA)
  )

  for (week in weeks) {
    week_index <- which(lls$Week == week)
    test_data <- win[win$Week == week,]
    test_hmm    <- depmix(
      response = formula,
      data     = test_data,
      nstates  = 20,
      ntimes   = c(nrow(test_data))
    )

    test_hmm <- setpars(test_hmm, getpars(fit_model))
    test_ll  <- forwardbackward(test_hmm)$logLik / nrow(test_data)

    lls[week_index,]$LL <- test_ll
  }

  return(lls)
}

# ------------------------------------------------------------
# Prepare Data
# ------------------------------------------------------------

ds_reg_full <- read_dataset("~/Downloads/TermProjectData.txt")
ds_anom1 <- read_dataset("~/Downloads/DataWithAnomalies1.txt")
ds_anom2 <- read_dataset("~/Downloads/DataWithAnomalies2.txt")
ds_anom3 <- read_dataset("~/Downloads/DataWithAnomalies3.txt")

for (c in feature_cols) {
	ds_reg_full[[c]] = scale(interpolate_na(ds_reg_full[[c]]))
	ds_anom1[[c]] = scale(interpolate_na(ds_anom1[[c]]))
	ds_anom2[[c]] = scale(interpolate_na(ds_anom2[[c]]))
	ds_anom3[[c]] = scale(interpolate_na(ds_anom3[[c]]))
}

# Extract a subset of the TermProjectData with the same time range as the anomalous data.
dsts_reg    <- as.numeric(ds_reg_full$Time)
dsts_mintime <- as.numeric(strptime("2007-12-01 14:07:00", format="%Y-%m-%d %H:%M:%S"))
dsts_maxtime <- as.numeric(strptime("2008-11-26 21:02:00", format="%Y-%m-%d %H:%M:%S"))
ds_reg      <- ds_reg_full[dsts_reg >= dsts_mintime & dsts_reg <= dsts_maxtime,]

# ------------------------------------------------------------
# Extract Time Windows for Each Dataset
# ------------------------------------------------------------

dsw_reg   <- extract_window(ds_reg)
dsw_anom1 <- extract_window(ds_anom1)
dsw_anom2 <- extract_window(ds_anom2)
dsw_anom3 <- extract_window(ds_anom3)

# ------------------------------------------------------------
# Calculate Log-Liklihoods for Each Week
# ------------------------------------------------------------
lls_anom1 <- eval_loglik(dsw_anom1)lls_anom2 <- eval_loglik(dsw_anom2)lls_anom3 <- eval_loglik(dsw_anom3)
lls_reg   <- eval_loglik(dsw_reg)

# Ensure that the baseline data does not contain anything for weeks
# not inside the anomalous data set.
lls_reg <- lls_reg[lls_reg$Week %in% lls_anom1$Week,]

# ------------------------------------------------------------
# Compare Log-Liklihoods against Baseline
# ------------------------------------------------------------

llsd_anom1 <- lls_reg
llsd_anom1$LL <- lls_reg$LL - lls_anom1$LL

llsd_anom2 <- lls_reg
llsd_anom2$LL <- lls_reg$LL - lls_anom2$LL

llsd_anom3 <- lls_reg
llsd_anom3$LL <- lls_reg$LL - lls_anom3$LL

# ------------------------------------------------------------
# Plot
# ------------------------------------------------------------

plot.new()
plot.window(
    xlim = c(min(llsd_anom1$Week), max(llsd_anom1$Week)),
    ylim = c(-1, 2.8)
)

axis(side = 1, at = llsd_anom1$Week)
axis(side = 2, at = seq(-3, 3, by = 0.5), las = 2)
for (week in llsd_anom1$Week) {
  abline(v = week, col = "grey")
}
abline(h = 0, col = "darkgreen")
abline(h = 0.5, col = "orange")
abline(h = -0.5, col = "orange")

points(llsd_anom1, pch = 16, col = "red")
points(llsd_anom2, pch = 16, col = "blue")
points(llsd_anom3, pch = 16, col = "pink")

legend("bottomleft", legend = c("Dataset 1", "Dataset 2", "Dataset 3"), col = c("red", "blue", "pink"), pch = 16)
title(
  main = "Analysis of Anomalous Datasets",
  xlab = "Week",
  ylab = "Difference from Baseline"
)
